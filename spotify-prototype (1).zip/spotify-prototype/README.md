# Wavelength: Spotify-inspired Web Player Prototype

UED100 User Experience Design, Assessment 2 (Keomonioddhom Buth, A00216603).

A front-end prototype built from the requirements and recommendations in Assessment 1
(UX and UI Requirement Analysis of the Spotify Web Player). It uses plain HTML, CSS and
JavaScript with no frameworks and no build step.

## How to run

1. Open the folder in Visual Studio Code.
2. Install the **Live Server** extension, right-click `index.html` and choose **Open with Live Server**
   (or simply double-click `index.html` to open it in a browser).

## Project structure

```
index.html              Semantic page structure
css/styles.css          Design tokens, grid layout, components, responsive rules
js/script.js            Search, filters, player, menu, form validation, preferences
assets/audio/*.wav      Synthesised demo tracks (8 seconds each)
assets/img/*.svg        Playlist cover artwork
tools/generate_assets.py  Script that regenerates the audio and artwork
```

## Features and the Assessment 1 finding each one addresses

| Feature | Assessment 1 finding |
|---|---|
| Sidebar links all have visible text labels, plus CSS tooltips | Small icons hard to find without labels; clearer tooltips |
| Hamburger menu / off-canvas drawer on small screens, Esc to close | Responsive navigation; more flexible navigation |
| Dismissible "New here?" guide, remembered with localStorage | Guidance for first-time users |
| Space = play/pause, skip link, visible focus, all controls are real buttons | Stronger keyboard support |
| Search with live filtering, playlist cards and filter chips | Searchable music library, playlist cards |
| Player: play/pause, previous/next, seek, volume, time, auto-next | Working playback controls |
| Skeleton loading cards, buffering state, error toasts | Loading indicators and graceful error handling |
| Save (heart) songs to Your Library, stored in localStorage | Library management for Premium and casual users |
| Free vs Premium comparison table | Unclear subscription restrictions |
| Contact form with accessible validation and character counter | Contact us form requirement |
| High-contrast mode, 44px touch targets, reduced-motion support | Strong colour contrast, accessibility (WCAG) |

## Coding techniques worth noting

* **CSS Grid named areas** build the app shell, and the layout is rearranged for mobile by changing only `grid-template-areas`.
* **CSS custom properties** hold all colours, so the high-contrast theme is a single block of overrides.
* **`auto-fill` + `minmax()`** makes the playlist grid responsive without media queries.
* **`attr()` tooltips** use a `data-title` attribute, so no JavaScript is needed.
* **Events drive the UI**: the play button reflects real `audio` events (`play`, `pause`, `ended`, `waiting`), not assumptions.
* **`IntersectionObserver`** powers the scroll-spy highlight in the navigation, which is cheaper than scroll listeners.
* **Debounced search** avoids re-rendering on every keystroke.
* **Security**: user-visible text is written with `textContent`, never `innerHTML`; localStorage access is wrapped in try/catch.

## Notes

* Artists, playlists and audio are fictional and generated for this prototype; no copyrighted media is used.
* The contact form is a front-end demo only; nothing is sent to a server.
* In a production build, authentication and playback would use Spotify's OAuth flow and Web Playback SDK, with tokens handled server-side.
